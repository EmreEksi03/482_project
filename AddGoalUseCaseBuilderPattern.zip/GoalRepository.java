public interface GoalRepository {
    void addGoal(Goal goal);
}