public class NetworkUtils {
    public static boolean isOnline() {
        return true; // Simulated online check
    }
}